% 1. Vamos criar um sinal senoidal para ver o que a transformada de Fourier
% nos retorna.


freq1 = 200;
period1 = 1 / freq1;
w1 = 2 * pi * freq1;
num_tsteps = 1000;
num_periods = 5;
tstep = num_periods * period1 / num_tsteps;
t = 0:tstep:(num_periods * period1);
x1 = sin(w1 * t);
figure, plot(t, x1);


% 2. Qual o tempo total amostrado pela função? Agora plote o espectro da
% transformada. 


plot (abs(fft(x1)));


% 3. O resultado lhe parece correto? Não especificamos os tempos em que os 
% pontos de x1 foram amostrados, como o Octave sabe a que frequência o 
% sinal está? Não sabe. A transformada é calculada em cima dos pontos, se 
% entram 1000 pontos, a transformada terá 1000 pontos. Quem atribui 
% significado aos pontos da transformada somos nós.


    % como acontece na imagem, o espectro parece correto pois se encontra 
    % nos extremos (0 e 1000), pois ainda não foi distribuido corretamente.


% 4. Vamos especificar as frequências obtidas no espectro. Elas devem 
% variar de zero até a máxima frequência que pode ser observada no 
% espectro. Um período da transformada de Fourier representa um tempo igual 
% ao período de amostragem (1/fs). A frequência de amostragem é obtida 
% dividindo-se o número de amostras pelo tempo amostrado, como segue:


n = size(x1, 2);
f_s = num_tsteps / (period1*num_periods);
f = f_s*(0:n-1)/n;
figure, plot (f, abs(fft(x1, n)));


% 5. Experimente manipular o valor de n para 6000, por exemplo. O que 
% acontece ao espectro? Seu centro muda de lugar? Explique o efeito 
% observado. Se alterarmos o número de períodos amostrados, o que acontece 
% com a máxima frequência do espectro de Fourier?


n = 6000;
num_periods = 10;
f_s = num_tsteps / (period1*num_periods);
f = f_s*(0:n-1)/n;
figure, plot (f, abs(fft(x1, n)));
% ao alterar o n para 6000, há a aparição de artefatos pois a transformada
% de Fourier não consegue representar o período faltante (quando há o 
% aumento de n para 6000, a transformada fica uma parte 'faltante'). Já ao 
% alterar o número de períodos, a frequência máxima diminui; por exemplo 
% com 50 períodos, a frequência máxima vai a 4000, e antes, com 5 periodos, 
% era 4x10^4. O centro não muda de lugar.


% 6. Existe uma simetria no primeiro gráfico da transformada que foi 
% plotado. Entretanto, esta não é a reflexão no zero [0 Hz] (seu gráfico 
% mostra dois meio períodos da série de Fourier). Para ver o espectro é 
% necessário usar fftshift(v), que desloca os valores em v de modo que a
% frequência zero Hz fique no centro.


y = abs(fft(x1, n));
y = fftshift(y);
f = f_s*(-n/2:n/2-1)/n;
figure, plot (f, y);


% 7. Vamos brincar de adicionar um sinal ao original, digamos de 800Hz. 
% Observe o resultado no espectro de Fourier.


freq2 = 800;
period2 = 1 / freq2;
w2 = 2 * pi * freq2;
x2 = sin(w2 * t);
x3 = x1 + x2*0.1;
figure, plot(t, x3);
n = size(x1, 2);
f_s = num_tsteps / (period1*num_periods);
f = f_s*(0:n-1)/n;
figure, plot (f, abs(fft(x3, n)));


% 8. Para obter um espectro com melhor resolução, podemos aumentar o número 
% de períodos amostrados de forma a aumentar o tempo de amostragem.


num_periods = 100; % agora amostramos 0.5 segundos e a frequência máxima de
% Fourier é 2KHz


% 9. Vamos adicionar uma componente DC agora. Para isto, vamos somar um 
% valor constante a x3


x4 = x3+0.1;


% 10. Calcule e plote a FFT novamente. Como ficou o espectro agora? (Para 
% facilitar a visualização, plote com a frequência zero no centro do 
% gráfico).


y = abs(fft(x4, n));
y = fftshift(y);
n = size(x4, 2);
f_s = num_tsteps / (period1*num_periods);
f = f_s*(-n/2:n/2-1)/n;
figure, plot (f, abs(fft(x4, n)));

