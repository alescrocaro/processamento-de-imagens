%imagem escura
img = imread('pratica5.png');

%obtem o histograma da imagem
A = imhist(img);

B = A/sum(A);
%soma cumulativa
C = cumsum(B);
C = C*(255);

novaImg = C(img+1);
novaImg = novaImg/255;

%Plota o histograma da nova imagem
figure(1);
imhist(novaImg);

%mostra imagem equalizada
figure(2);
imshow(novaImg);


%imagem clara
img = imread('pratica5_c.png');

A = imhist(img);

B = A/sum(A);
C = cumsum(B);
C = C*(255);

novaImg = C(img+1);
novaImg = novaImg/255;

figure(3);
imhist(novaImg);

figure(4);
imshow(novaImg);